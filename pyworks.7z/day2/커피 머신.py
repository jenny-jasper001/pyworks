#커피 자동판매기 프로그램
coffe = 5

#돈 넣는 건 계속 반복
while True:
    

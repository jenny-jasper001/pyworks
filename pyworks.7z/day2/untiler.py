for i in range(0, 5): #0번은 1번 회전했다
    for j in range(0, 5-i): 
        print('*', end='')
    print()

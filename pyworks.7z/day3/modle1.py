#수학 관련 모듈
#외부의 함수나 클래스등 모듈을 사용할때
#import 명령어를 사용한다
import math

#내림
print(math.floor(2.56)) #2가 출력

#올림
print(math.ceil(10.12)) #11가 출력
 
#제곱근 예) 25 -> 5 , 9->3
print(math.sqrt(25))  #5가 출력

#원주율
print(math.pi)

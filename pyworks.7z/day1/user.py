#변수 만들기(선언)
user = "클라우드"
print(user) 
